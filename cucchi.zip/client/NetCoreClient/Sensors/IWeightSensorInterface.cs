﻿namespace NetCoreClient.Sensors
{
    internal interface IWeightSensorInterface
    {
        int Weight();
    }
}