﻿using System.Net;

namespace NetCoreClient.Protocols
{
    class Http : ProtocolInterface
    {
        private string fine;
        //private HttpWebRequest httpWebRequest;

        public Http(string fine)
        {
            this.fine = fine;
        }

        public async void Send(string data)
        {
            var client = new HttpClient();

            var result = await client.PostAsync(fine, new StringContent(data));

            Console.Out.WriteLine(result.StatusCode);
        }
    }
}
