﻿namespace NetCoreClient.Sensors
{
    interface ISpeedSensorInterface
    {
        int Speed();
    }
}
